package com.thoughtworks.recruitme.characterCount;

import java.util.HashMap;
import java.util.Map;

public class CharacterCount {
  public static Map<Character, Integer> countCharacters(String string) {
    
	  char[] ar=string.toCharArray();
	  Map<Character,Integer> map=new HashMap<>();
	  for(int i=0;i<ar.length;i++)
	  {
		  char ch=ar[i];
		  if(ch!=' ')
		  {
		  if(!map.containsKey(ch))
			  map.put(ch,1);
		  else
			  map.put(ch,map.get(ch)+1);
		  }
	  }
	  //System.out.println(map);
	  return map;
	  
  }
}
