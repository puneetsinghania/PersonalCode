package com.thoughtworks.recruitme.equalityProblem;

import com.thoughtworks.recruitme.services.MethodNotImplementedException;
//Last case not working as expected
public class Player {
	final String name;
	final int jerseyNumber;
  public Player(String name, int jerseyNumber) {
	  this.name=name;
	  this.jerseyNumber=jerseyNumber;
  }

  public boolean equals(Player other)  {
	  //System.out.println(this.name+"-->"+other.name+"-->"+this.jerseyNumber+"-->"+other.jerseyNumber);
	  if(this.name.equals(other.name) && this.jerseyNumber==other.jerseyNumber)
		  return true;
	  else
		  return false;
	  
	  
   // throw new MethodNotImplementedException("Method eqauls in class Player not implemented yet");
  }

}
