package com.thoughtworks.recruitme.expressionValidator;

import java.util.Stack;

import com.thoughtworks.recruitme.services.MethodNotImplementedException;

public class ExpressionValidatorImpl implements ExpressionValidator {
    public boolean isBalancedExpression(String expression) throws MethodNotImplementedException {
       char[] ar=expression.toCharArray();
      // {{[[(())]]}}
       Stack<Character> stack=new Stack<Character>();
       for(int i=0;i<ar.length;i++)
       {
    	   char ch=ar[i];
    	   switch(ch)
    	   {
    	   case '{':
    	   case '[':
    	   case '(':
    		   stack.push(ch);
    		   break;
    	   case ')':
    		   if(stack.isEmpty() || (stack.pop()!=('(')))
    		   {return false;}
    		   break;
    	   case ']':
    		   if(stack.isEmpty() || (stack.pop()!=('[')))
    	   	   {return false;}
    		   break;
    	   case '}':
    		   if(stack.isEmpty() || (stack.pop()!=('{')))
    	   	   {return false;}
    		   break;
    	   }
       }
       //System.out.println(stack);
    	return stack.isEmpty();
    	// throw new MethodNotImplementedException("isBalancedExpression");
    }
}
