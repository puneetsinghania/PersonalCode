package com.thoughtworks.recruitme.findClassName;

import com.thoughtworks.recruitme.services.MethodNotImplementedException;

public class ClassIdentifierImpl<T, E> implements ClassIdentifier<T, E> {
  public String[] identifyClasses(T parameterOne, E parameterTwo) throws Exception {
   
	  String[] ar=new String[2];
		  ar[0]=parameterOne.getClass().getSimpleName();
		  ar[1]=parameterTwo.getClass().getSimpleName();
	  return ar;
	  
	  // throw new MethodNotImplementedException("Identify Classes");
  }
}
