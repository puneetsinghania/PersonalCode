package com.thoughtworks.recruitme.findClassName;

public class Animal {
}
