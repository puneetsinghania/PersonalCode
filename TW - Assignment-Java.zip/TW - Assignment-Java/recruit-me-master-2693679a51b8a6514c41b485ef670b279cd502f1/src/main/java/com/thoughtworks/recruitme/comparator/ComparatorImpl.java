package com.thoughtworks.recruitme.comparator;
//NOT WORKING
import com.thoughtworks.recruitme.services.MethodNotImplementedException;

public class ComparatorImpl<T> implements Comparator<T> {

  public T findGreater(T parameterOne, T parameterTwo) throws Exception {
    
	  	//return ((parameterOne.compareTo(parameterTwo)>=0)? parameterOne : parameterTwo);
	  
	  throw new MethodNotImplementedException("findGreater");
  }
}
