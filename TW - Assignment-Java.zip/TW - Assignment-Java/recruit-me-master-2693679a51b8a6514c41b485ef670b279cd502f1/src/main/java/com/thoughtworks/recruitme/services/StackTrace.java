package com.thoughtworks.recruitme.services;

public interface StackTrace {
    void clearStackTrace() throws Exception;
}
