package com.thoughtworks.recruitme.services;

/**
 * Created for ThoughtWorks on 3/13/17.
 */
public class RandomError {
    private int code;

    public RandomError(int code){

        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
