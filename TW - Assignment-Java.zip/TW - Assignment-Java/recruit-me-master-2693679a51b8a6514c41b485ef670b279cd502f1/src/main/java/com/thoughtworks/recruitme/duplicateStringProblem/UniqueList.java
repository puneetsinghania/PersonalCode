package com.thoughtworks.recruitme.duplicateStringProblem;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class UniqueList {
  public static List<String> deDuplicate(List<String> list) {
    
	  
	  Set<String> set=new LinkedHashSet<>();
	  
	  for(String str:list)
	  {
		  set.add(str);
	  }
	  List<String> list2=new ArrayList<>(set);
	  //System.out.println(list2);
	  return list2;
	  //return null;
  }
}
