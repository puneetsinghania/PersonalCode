package com.thoughtworks.recruitme.primes;

import java.util.ArrayList;
import java.util.List;

public class Prime {

  public List<Integer> findPrimes(int n) {
    
	  List<Integer> list=new ArrayList<>();
	  for(int num=0;num<=n;num++)
	  {
		  if(isPrime(num)==true)
		  {
			  list.add(num);
		  }
	  }
	  return list;
	  //return null;
  }
  boolean isPrime(int num)
  {
	  if(num==0||num==1)
		  return false;
	  else
	  {
		  for(int i=2;i<=num/2;i++)
		  {
			  if(num%i==0)
			  {
			  return false;
			  }
		  }
		  return true;
	  }
  }
}
